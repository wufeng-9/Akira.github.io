如果不能添加社会化组件就把本目录下的一些文件删除

js：jquery-1.70.2.js、jquery.share.min.js

css：share.min.css
