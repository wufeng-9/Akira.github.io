本项目已支援996ICU项目：<a href="https://996.icu"><img src="https://img.shields.io/badge/link-996.icu-red.svg"></a>
#
![](http://img0.dfjcx.cn/2018/11/timg.jpg)

一个Wordpress二次元个人博客主题，简约而不简单，Made BY 江程训。

最近总感觉作为一个Wordpress老玩家（其实也不算多老，也就接触这个网站程序一年），自己似乎少了点什么，于是就做了这款主题。

**本主题在Akina的分支Siren的基础上魔改**，希望大家喜欢，也希望大家能够在Github去Star这个主题。

# 主题基本信息

-   主题名称：Mokore
-   主题作者：[江程训（CensuJiang）](https://censujiang.com/)
-   当前版本：1.2.1（2019-4-5持续更新中）
-   主题类型：WordPress，个人博客，博客主题，二次元，自媒体，大佬必备
-   特色描述：简约而不简单，特别适合喜欢二次元的自媒体、程序员和画师
-   兼容环境：**PHP5.6 +**，WordPress 4.9+
-   官方演示：[https://mokore.dfjcx.cn/](https://mokore.dfjcx.cn/)
-   主题QQ群： [_346363551_](http://shang.qq.com/wpa/qunwpa?idkey=d99e5a83cbba65cd3054bd38b0c9b6bb8cc524b32d269ccb5d67e6d46723f569)
-   GIthub下载：[https://github.com/censujiang/Mokore](https://github.com/censujiang/Mokore)
-   这个版本只修复了BUG哦

# 功能简介

首页社交组件，让您的Fans轻松联系到您~

简洁阅读风格，看屏幕爽到爆炸

随机二次元封面图，拯救选择困难症

三图广告位，助力访客更加了解本站

有趣的提示文字，浓浓的次元风格

文章目录功能，一键导航至所需段落

......

更多功能，需要您细细品尝

# 预览图

![](http://img0.dfjcx.cn/2018/11/屏幕截图196.png)

![](http://img0.dfjcx.cn/2018/11/屏幕截图197.png)![](http://img0.dfjcx.cn/2018/11/屏幕截图198.png)![](http://img0.dfjcx.cn/2018/11/屏幕截图199.png)![](http://img0.dfjcx.cn/2018/11/屏幕截图200.png)

# 主题描述

如果您正在寻找一款既简单却不简约，既丰富却不复杂，不仅个性而且另类的WordPress 主题。如果这个页面荣幸地被您访问到，那么这款主题极有可能是您的“一生中最爱”。

Mokore是由江程训根据Akina-Siren编写的一款Wordpress二次元简约个人博客主题，这是一个灰常好玩的主题，总之用它来搭建您自己的Wordpress站点是最不错的啦。

这款主题是我江程训人生中的第一个Wordpress作品，我会持续更新，本主题在编写过程中引用了一些代码或程序亦或是其他的东西（例如Akina和Siren），详情请见[Copyright界面](https://mokore.dfjcx.cn/copyright)。

# 使用中遇到问题？

欢迎在[官方 QQ 交流群](http://shang.qq.com/wpa/qunwpa?idkey=d99e5a83cbba65cd3054bd38b0c9b6bb8cc524b32d269ccb5d67e6d46723f569)中与小伙伴们交流.。

# 声明

本主题基于Akina的分支Siren，江程训仅在此主题基础上进行了一些魔改与微创新，禁止任何人利用任何理由和方式倒卖本主题，另外本主题授权协议为Apache2.0，请勿违反规则。

# 下载主题

Github地址：[https://github.com/censujiang/Mokore](https://github.com/censujiang/Mokore)

Wordpress官方下载：正在提交审核中，请稍后再看

**非常感谢您选择江程训的Mokore主题，我会持续更新，也希望您把此作品推荐给其他站长或者博主。**
